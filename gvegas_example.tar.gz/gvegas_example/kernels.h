#pragma once

#include "xorshift.cu"

#include "gVegasFunc.cu"
#include "gVegasCallFunc.cu"
#include "gVegas.cu"
