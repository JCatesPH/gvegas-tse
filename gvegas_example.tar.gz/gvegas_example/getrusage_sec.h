#pragma once

void getrusage_sec(double& utime, double& stime);
double getrusage_usec();
double getrusage_ssec();
